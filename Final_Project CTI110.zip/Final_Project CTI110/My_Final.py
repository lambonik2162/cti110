from flask import Flask, request, render_template
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart

app = Flask(__name__)

# Function to send email
def send_email(subject, body, to_email):
    from_email = "your_email@gmail.com"  # Your email
    from_password = "your_email_password"  # Your email password

    msg = MIMEMultipart()
    msg['From'] = from_email
    msg['To'] = to_email
    msg['Subject'] = subject

    msg.attach(MIMEText(body, 'plain'))

    try:
        server = smtplib.SMTP('smtp.gmail.com', 587)
        server.starttls()
        server.login(from_email, from_password)
        text = msg.as_string()
        server.sendmail(from_email, to_email, text)
        server.quit()
        return "Email sent successfully!"
    except Exception as e:
        return f"Error sending email: {str(e)}"

# Form routes
@app.route('/contact', methods=['POST'])
def contact_form():
    name = request.form.get('name')
    email = request.form.get('email')
    message = request.form.get('message')

    subject = f"New Message from {name}"
    body = f"Name: {name}\nEmail: {email}\nMessage: {message}"

    # Send email to your address
    send_email(subject, body, "lambonik2162@student.faytechcc.edu")

    return f"Thank you, {name}! We have received your message and will get back to you shortly."

@app.route('/visa-assessment', methods=['POST'])
def visa_assessment_form():
    name = request.form.get('name')
    email = request.form.get('email')
    concern = request.form.get('question')

    subject = f"Visa Assessment Request from {name}"
    body = f"Name: {name}\nEmail: {email}\nVisa Concern: {concern}"

    # Send email to your address
    send_email(subject, body, "lambonik2162@student.faytechcc.edu")

    return f"Thank you, {name}! We will review your visa concern and get back to you soon."

@app.route('/book-consultation', methods=['POST'])
def book_consultation_form():
    name = request.form.get('name')
    email = request.form.get('email')
    consultation_details = request.form.get('consultation')

    subject = f"Consultation Request from {name}"
    body = f"Name: {name}\nEmail: {email}\nConsultation Details: {consultation_details}"

    # Send email to your address
    send_email(subject, body, "lambonik2162@student.faytechcc.edu")

    return f"Thank you, {name}! We will contact you soon to schedule your consultation."

@app.route('/get-representation', methods=['POST'])
def get_representation_form():
    name = request.form.get('full-name')
    email = request.form.get('email')
    case_details = request.form.get('case-details')

    subject = f"Legal Representation Request from {name}"
    body = f"Name: {name}\nEmail: {email}\nCase Details: {case_details}"

    # Send email to your address
    send_email(subject, body, "lambonik2162@student.faytechcc.edu")

    return f"Thank you, {name}! We will review your case and get in touch soon."

if __name__ == '__main__':
    app.run(debug=True)
